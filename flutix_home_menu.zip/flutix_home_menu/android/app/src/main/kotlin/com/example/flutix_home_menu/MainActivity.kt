package com.example.flutix_home_menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
